#!/usr/bin/env bash
set -euo pipefail
bash verify-frontend.sh
bash verify-backend.sh
