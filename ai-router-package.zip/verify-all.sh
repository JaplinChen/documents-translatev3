#!/usr/bin/env bash
set -e
bash verify-frontend.sh
bash verify-backend.sh
