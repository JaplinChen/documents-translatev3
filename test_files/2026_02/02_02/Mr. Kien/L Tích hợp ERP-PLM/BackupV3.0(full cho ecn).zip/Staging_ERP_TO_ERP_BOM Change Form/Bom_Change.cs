﻿using System.Data;
using System.Data.SqlClient;



namespace Staging_ERP_TO_ERP_BOM_Change_Form
{    
    public class Bom_Change
    {

        // THỰC HIỆN TOÀN BỘ QUÁ TRÌNH TỪ TAOOJ PHIẾU BOMI02 ĐẾN LÚC ĐIỀN DỮ LIỆU VÀO BẢNG BOM CỦA ERP BOMMC VÀ BOMMD
        public static void Bom_change(SqlConnection erp, SqlConnection plm, SqlConnection staging, string ecn, string creator, string company, int loaiPhieuDoi, long maPhieuDoi, ref bool success)
        {

            ////viết hàm truyền dữ liệu vào bảng BOMTA_Staging_ERP, BOMTB_Staging_ERP, BOMTC_Staging_ERP
            //using (var tran = staging.BeginTransaction())
            //{
            //    // truyền vào bảng trung gian
            //    try
            //    {
            //        Insert_BOMTA_Staging_ERP(plm, staging, tran, ecn, creator, company, loaiPhieuDoi, maPhieuDoi);
            //        Insert_BOMTB_Staging_ERP_And_BOMTC_Staging_ERP(plm, erp, staging, tran, ecn, creator, company, loaiPhieuDoi, maPhieuDoi);
            //    }
            //    catch (Exception ex)
            //    {
            //        //tran.Rollback();
            //        throw;
            //    }


            //    tran.Commit();  // hoặc tran.Rollback() nếu có lỗi

            //}


            // Lấy danh sách cột bảng ERP 1 lần cho các bảng cần dùng
            var colsBOMTA = Helper.GetTableColumns(erp, "BOMTA");
            var colsBOMTB = Helper.GetTableColumns(erp, "BOMTB");
            var colsBOMTC = Helper.GetTableColumns(erp, "BOMTC");

            // Đọc từng record BOMTA_Staging_ERP chưa sync
            string selectTA = @$"SELECT * FROM BOMTA_Staging_ERP  WHERE SyncStatus = 0 and TA002  = {maPhieuDoi}";
            var taRows = Helper.ReadRows(staging, selectTA);

            int totalTA = 0;
            foreach (var ta in taRows)
            {
                totalTA++;
                object TA001 = ta.GetValueOrDefault("TA001") ?? DBNull.Value;
                object TA002 = ta.GetValueOrDefault("TA002") ?? DBNull.Value;

                Console.WriteLine($"\n (BOMTA) Xu ly TA001={TA001}, TA002={TA002} ...");

                // Bắt transaction trên DB chính (erp) cho 1 phiếu BOMTA
                using (var tran = erp.BeginTransaction())
                {
                    try
                    {
                        // Insert BOMTA from BOMTA_Staging_ERP
                        try
                        {
                            Helper.InsertRow(erp, tran, "BOMTA", ta, colsBOMTA, company);
                        }
                        //SqlException
                        catch (Exception ex)
                        {
                            Helper.TransferFailed(staging, "ECN_Test", ecn, "3");

                            Console.WriteLine("check có có lệnh ra 3");
                            success = false;
                            throw;
                            //return;
                        }
                        // Cập nhật TA
                        Helper.UpdateStagingSyncStatus(staging, "BOMTA_Staging_ERP", new Dictionary<string, object> { { "TA001", TA001 }, { "TA002", TA002 } });

                        // Gọi Sync BOMTB theo TA
                        var tbRows = Helper.ReadRows(staging, "SELECT * FROM BOMTB_Staging_ERP WHERE TB001 = @TB001 AND TB002 = @TB002 AND SyncStatus = 0",
                            new Dictionary<string, object> { { "@TB001", TA001 }, { "@TB002", TA002 } });

                        int tbCount = 0;
                        foreach (var tb in tbRows)
                        {
                            tbCount++;
                            object TB001 = tb.GetValueOrDefault("TB001") ?? DBNull.Value;
                            object TB002 = tb.GetValueOrDefault("TB002") ?? DBNull.Value;
                            object TB003 = tb.GetValueOrDefault("TB003") ?? DBNull.Value;

                            Console.WriteLine($"   (BOMTB) Xu ly TB001={TB001}, TB002={TB002}, TB003={TB003} ...");

                            // Insert BOMTB
                            try
                            {
                                Helper.InsertRow(erp, tran, "BOMTB", tb, colsBOMTB, company);
                                // Update BOMMC dựa trên dữ liệu TB (giữ nguyên logic cũ)
                                UpdateBOMMC_FromBOMTB(erp, tran, tb);
                            }
                            catch (Exception ex)
                            {
                                Helper.TransferFailed(staging, "ECN_Test", ecn, "4");
                                success = false;
                                throw;

                                //return;
                            }
                            // Cập nhật TB
                            Helper.UpdateStagingSyncStatus(staging, "BOMTB_Staging_ERP", new Dictionary<string, object> { { "TB001", TB001 }, { "TB002", TB002 }, { "TB003", TB003 } }, matchColumnsForWhere: new List<string> { "TB001", "TB002", "TB003" });


                            // Với mỗi BOMTB, đọc BOMTC tương ứng và xử lý
                            var tcRows = Helper.ReadRows(staging,
                                "SELECT * FROM BOMTC_Staging_ERP WHERE TC001 = @TC001 AND TC002 = @TC002 AND TC003 = @TC003 AND SyncStatus = 0",
                                new Dictionary<string, object> { { "@TC001", TB001 }, { "@TC002", TB002 }, { "@TC003", TB003 } });

                            int tcCount = 0;
                            foreach (var tc in tcRows)
                            {
                                tcCount++;
                                object TC001 = tc.GetValueOrDefault("TC001") ?? DBNull.Value;
                                object TC002 = tc.GetValueOrDefault("TC002") ?? DBNull.Value;
                                object TC003 = tc.GetValueOrDefault("TC003") ?? DBNull.Value;
                                object TC004 = tc.GetValueOrDefault("TC004") ?? DBNull.Value;

                                Console.WriteLine($"     (BOMTC) Xu ly TC001={TC001}, TC002={TC002}, TC003={TC003}, TC004={TC004} ...");

                                // Insert BOMTC
                                try
                                {

                                    Helper.InsertRow(erp, tran, "BOMTC", tc, colsBOMTC, company);
                                    // MERGE BOMMD (giữ nguyên SQL MERGE đã có) - dùng transaction
                                    MergeBOMMD_FromBOMTC(erp, tran, ta, tb, tc, company);
                                }
                                catch (Exception ex)
                                {
                                    Helper.TransferFailed(staging, "ECN_Test", ecn, "5");
                                    success = false;
                                    throw;
                                    //return;
                                }
                                // Cập nhật TC cho các TB liên quan
                                Helper.UpdateStagingSyncStatus(staging, "BOMTC_Staging_ERP", new Dictionary<string, object> { { "TC001", TC001 }, { "TC002", TC002 }, { "TC003", TC003 }, { "TC004", TC004 } }, matchColumnsForWhere: new List<string> { "TC001", "TC002", "TC003", "TC004" });



                                // Nếu tất cả ok cho TC, cập nhật SyncStatus của TC trong staging (chỉ khi erp commit thành công)
                            }

                            //// Cập nhật TB
                            //Helper.UpdateStagingSyncStatus(staging, "BOMTB_Staging_ERP", new Dictionary<string, object> { { "TB001", TB001 }, { "TB002", TB002 }, { "TB003", TB003 } }, matchColumnsForWhere: new List<string> { "TB001", "TB002", "TB003" });
                        }

                        // Nếu tất cả thành công trong transaction thì commit
                        tran.Commit();

                        // Sau khi commit trên erp, cập nhật SyncStatus trên staging cho TA, TB, TC đã xử lý


                        //// Cập nhật TA
                        //Helper.UpdateStagingSyncStatus(staging, "BOMTA_Staging_ERP", new Dictionary<string, object> { { "TA001", TA001 }, { "TA002", TA002 } });
                                              
                        if (success == true) Console.WriteLine($" Hoan tat phieu BOMTA TA001={TA001}, TB_Rows={tbRows.Count}.");

                    }
                    catch (Exception ex)
                    {
                    success = false;
                    try { tran.Rollback(); } catch { }
                    Console.WriteLine("❌ Loi khi xu ly phieu BOMTA - rollback: " + ex.Message);
                    }

                // Nếu cần, ghi log chi tiết hoặc push thông báo
                }
            }
            if (success) Console.WriteLine($"\n=== HOAN TAT - Da xy ly {totalTA} DON THAY DOI BOMTA ");
        }

        // LẤY TIÊU ĐỀ PHIẾU CẢU ERP ĐỂ ĐIỀN DỮ LIỆU MÀ PHIEUS PHIẾU
        public static long Get_TA002(long TA002, SqlConnection erp, SqlConnection staging)
        {
            long maxMaPhieuInERP = 0;
            long maxMaPhieuInStaging = 0;

            string query = "SELECT TOP 1 max(TA002) from BOMTA";

            using (SqlCommand cmd = new SqlCommand(query, erp))
            {
                object result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    maxMaPhieuInERP = long.Parse(result.ToString());
                }
            }


            // So sánh để quyết định mã phiếu cuối cùng
            if (TA002 > maxMaPhieuInERP
                //&& TA002 > maxMaPhieuInStaging
                )
            {
                return TA002;
            }
            else
            {
                return maxMaPhieuInERP + 1;
            }
        }

        // =====================================================CẬP NHẬP DỮ LIỆU VÀO CÁC BẢNG TỦNG GIAN
        public static void Insert_BOMTA_Staging_ERP(SqlConnection plm, SqlConnection staging, SqlTransaction stagingTran, string ecn, string creator, string company, int loaiPhieuDoi, long maPhieuDoi)
        {
            // các thành phần lấy là thay đổi thêm mới và xóa
            string sqlPLM = $@"
                    SELECT 
                    -- AS COMPANY,	
                    -- AS CREATOR,	
                    -- AS USR_GROUP,	
                    CONVERT(varchar(8),GETDATE(),112) AS CREATE_DATE,	
                    -- AS MODIFIER,	
                    -- AS MODI_DATE,	
                    -- AS FLAG,	
                    -- AS TA001,	
                    -- AS TA002,	
                    CONVERT(varchar(8),CREATED_ON,112) as TA003,	
                    -- AS TA004,	
                    [DESCRIPTION] AS TA005,	
                    ITEM_NUMBER AS TA006,
                    -- AS TA007,	
                    -- AS TA008,	
                    CONVERT(varchar(8),CREATED_ON,112) as TA009
                    -- AS TA010,	
                    -- AS TA011,	
                    -- AS TA012,	
                    -- AS TA013,	
                    -- AS TA014,	
                    -- AS TA015,	
                    -- AS TA016,	
                    -- AS TA017,
                     from innovator.SIMPLE_ECO where ITEM_NUMBER =N'{ecn}'
                ";
            // cập nhật vào bảng BOMTA_Staging_ERP các  trường thay đổi trong PLM

            using (SqlCommand cmd = new SqlCommand(sqlPLM, plm))
            {
                // Nếu plm có transaction thì có thể truyền thêm transaction của PLM, nếu cần
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        // insert vào staging như bạn đang làm
                        using (SqlCommand insert = new SqlCommand(
                            @"INSERT INTO BOMTA_Staging_ERP (SyncStatus, CREATOR,	CREATE_DATE, FLAG,
                                                TA001, TA002, TA003, TA004, TA005, TA006, TA007, TA008, TA009, TA010, TA011, TA012, TA013, TA014, TA015, TA016, TA017)
                                 VALUES ( @SyncStatus, @CREATOR,	CONVERT(varchar(8),GETDATE(),112), @FLAG,
                                            @TA001, @TA002, @TA003, @TA004, @TA005, @TA006, @TA007, @TA008, @TA009, @TA010, @TA011, @TA012, @TA013, @TA014, @TA015, @TA016, @TA017)",
                              staging, stagingTran))
                        {
                            insert.Parameters.AddWithValue("@SyncStatus", '0');
                            insert.Parameters.AddWithValue("@CREATOR", creator);
                            insert.Parameters.AddWithValue("@FLAG", "1");

                            insert.Parameters.AddWithValue("@TA001", loaiPhieuDoi);
                            insert.Parameters.AddWithValue("@TA002", maPhieuDoi);
                            insert.Parameters.AddWithValue("@TA003", rd["TA003"] ?? DBNull.Value);
                            insert.Parameters.AddWithValue("@TA004", "0");
                            insert.Parameters.AddWithValue("@TA005", rd["TA005"] ?? DBNull.Value);
                            insert.Parameters.AddWithValue("@TA006", rd["TA006"] ?? DBNull.Value);
                            insert.Parameters.AddWithValue("@TA007", "Y"); // xác nhận đơn thay đổi
                            insert.Parameters.AddWithValue("@TA008", "0");
                            insert.Parameters.AddWithValue("@TA009", rd["TA009"] ?? DBNull.Value); // ngày chứng từ đang ko biueets truyền là j?????????                     
                            insert.Parameters.AddWithValue("@TA010", creator);
                            insert.Parameters.AddWithValue("@TA011", "N");
                            insert.Parameters.AddWithValue("@TA012", "0");
                            insert.Parameters.AddWithValue("@TA013", "0.000000");
                            insert.Parameters.AddWithValue("@TA014", "0.000000");
                            insert.Parameters.AddWithValue("@TA015", "");
                            insert.Parameters.AddWithValue("@TA016", "");
                            insert.Parameters.AddWithValue("@TA017", "");

                            insert.ExecuteNonQuery();
                        }
                    }
                }
            }

        }
        public static void Insert_BOMTB_Staging_ERP_And_BOMTC_Staging_ERP(SqlConnection plm, SqlConnection erp, SqlConnection staging, SqlTransaction stagingTran, string ecn, string creator, string company, int loaiPhieuDoi, long maPhieuDoi)
        {

            string selectTB004 = $@"
                                SELECT  
                                    PART.KEYED_NAME as NAME

                                FROM innovator.SIMPLE_ECO_AFFECTED_ITEM SEAI
                                JOIN innovator.SIMPLE_ECO SE ON SE.CONFIG_ID = SEAI.SOURCE_ID
                                JOIN innovator.AFFECTED_ITEM AI ON SEAI.RELATED_ID = AI.ID
                                JOIN innovator.PART PART ON PART.ID = AI.NEW_ITEM_ID
                                WHERE 
                                -- SE.STATE = 'Released' and 
                                SE.ITEM_NUMBER ='{ecn}' ";
            var TB004_Rows = Helper.ReadRows(plm, selectTB004);
            int total_TB004 = 0;
            foreach (var varTB004 in TB004_Rows)
            {
                total_TB004++;
                // CREATED BANG BOMTB_STAGING_ERP 
                string TB004 = varTB004["NAME"].ToString();
                string sql_ERP_Get_BOMMC = $@"
                    SELECT MC001 AS TB104,
                            MC002 AS TB105,
                            MC003 AS TB106,
                            MC004 AS TB108,
                            MC005 as TB109,
                            MC006 AS TB110,
                            MC007 AS TB111,
                            MC008 AS TB112,
                            MC009 AS TB107,
                            MC010 AS TB113,
                            MC011 AS TB114,
                            MC012 AS TB115,
                            MC013 AS TB116,
                            MC014 AS TB117,
                            MC015 AS TB118
                    FROM BOMMC
                    WHERE TRIM(MC001) = TRIM(N'{TB004}')
                    ";
                using (SqlCommand cmd = new SqlCommand(sql_ERP_Get_BOMMC, erp))
                {
                    // Nếu plm có transaction thì có thể truyền thêm transaction của PLM, nếu cần
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            // insert vào staging như bạn đang làm
                            using (SqlCommand insert = new SqlCommand(
                                @"INSERT INTO BOMTB_Staging_ERP (SyncStatus, CREATOR,	CREATE_DATE, FLAG,
                                                TB001,	TB002,	TB003,	TB004,	TB005,	TB006,	TB007,	TB008,	TB009,	TB010,	TB011,	TB012,	TB013,	TB014,	TB015,	TB016,	TB017,	TB018,	
                                                TB104,	TB105,	TB106,	TB107,	TB108,	TB109,	TB110,	TB111,	TB112,	TB113,	TB114,	TB115,	TB116,	TB117,	TB118
                                )
                                 VALUES ( @SyncStatus, @CREATOR,	CONVERT(varchar(8),GETDATE(),112), @FLAG,
                                            @TB001,	@TB002,	@TB003,	@TB004,	@TB005,	@TB006,	@TB007,	@TB008,	@TB009,	@TB010,	@TB011,	@TB012,	@TB013,	@TB014,	@TB015,	@TB016,	@TB017,	@TB018,	
                                            @TB104,	@TB105,	@TB106,	@TB107,	@TB108,	@TB109,	@TB110,	@TB111,	@TB112,	@TB113,	@TB114,	@TB115,	@TB116,	@TB117,	@TB118
                                )",
                                  staging, stagingTran))
                            {
                                insert.Parameters.AddWithValue("@SyncStatus", "0");
                                insert.Parameters.AddWithValue("@CREATOR", creator);
                                insert.Parameters.AddWithValue("@FLAG", "1");

                                insert.Parameters.AddWithValue("@TB001", loaiPhieuDoi);
                                insert.Parameters.AddWithValue("@TB002", maPhieuDoi);
                                insert.Parameters.AddWithValue("@TB003", total_TB004.ToString("D4"));
                                insert.Parameters.AddWithValue("@TB004", TB004);
                                insert.Parameters.AddWithValue("@TB005", rd["TB105"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB006", rd["TB106"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB007", rd["TB107"] == DBNull.Value ? DBNull.Value : (int.Parse(rd["TB107"].ToString()) + 1).ToString(new string('0', rd["TB107"].ToString().Length)));
                                insert.Parameters.AddWithValue("@TB008", rd["TB108"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB009", rd["TB109"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB010", rd["TB110"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB011", rd["TB111"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB012", "Y");
                                insert.Parameters.AddWithValue("@TB013", rd["TB113"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB014", rd["TB114"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB015", rd["TB115"] ?? DBNull.Value);
                                //insert.Parameters.AddWithValue("@TB016", rd["TB116"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB016", "1");
                                insert.Parameters.AddWithValue("@TB017", rd["TB117"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB018", rd["TB118"] ?? DBNull.Value);

                                insert.Parameters.AddWithValue("@TB104", TB004);
                                insert.Parameters.AddWithValue("@TB105", rd["TB105"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB106", rd["TB106"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB107", rd["TB107"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB108", rd["TB108"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB109", rd["TB109"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB110", rd["TB110"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB111", rd["TB111"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB112", rd["TB112"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB113", rd["TB113"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB114", rd["TB114"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB115", rd["TB115"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB116", rd["TB116"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB117", rd["TB117"] ?? DBNull.Value);
                                insert.Parameters.AddWithValue("@TB118", rd["TB118"] ?? DBNull.Value);


                                insert.ExecuteNonQuery();
                            }
                        }
                    }

                }

                // CREATED BANG BOMTC_STAGING_ERP 
                Insert_BOMTC_Staging_ERP(plm, erp, staging, stagingTran, ecn, creator, company, loaiPhieuDoi, maPhieuDoi, total_TB004.ToString("D4"), TB004); // total_TB004.ToString("D4") laf STT TB003 orr TC003

            }

            // cập nhật vào bảng BOMTB_Staging_ERP các  trường thay đổi trong PLM


        }
        public static void Insert_BOMTC_Staging_ERP(SqlConnection plm, SqlConnection erp, SqlConnection staging, SqlTransaction stagingTran, string ecn, string creator, string company, int TC001, long TC002, string TC003, string MD001)
        {
            List<string> listTC004 = new List<string>();
            // các thành phần lấy là thay đổi thêm mới và xóa
            string sql_PLM_Get_BOMTC = @$"
                                    --- TÌM NHỮNG NVL CHANGE TRONG bom
                                    ---- DK bat buoc sate    SE.STATE = 'Released' 
                                WITH BOM_CU AS (
                                    -- BOM cũ
                                    SELECT  
                                        PART.KEYED_NAME AS BOM,
                                        PART_BOM.SORT_ORDER AS STT,

                                        Information_BOM.KEYED_NAME AS MaSP,
                                        Information_BOM.UNIT AS DV,

                                        PART_BOM.GTO_BASE_QTY AS MauSo,
                                        PART_BOM.GTO_LOSS AS TyLeHaoMon,
                                        PART_BOM.QUANTITY AS LuongDung

                                    from innovator.SIMPLE_ECO SE
                                    left JOIN innovator.SIMPLE_ECO_AFFECTED_ITEM SEAI ON SE.CONFIG_ID = SEAI.SOURCE_ID
                                    -- FROM innovator.SIMPLE_ECO_AFFECTED_ITEM SEAI
                                    -- JOIN innovator.SIMPLE_ECO SE ON SE.CONFIG_ID = SEAI.SOURCE_ID
                                    left JOIN innovator.AFFECTED_ITEM AI ON SEAI.RELATED_ID = AI.ID
                                        JOIN innovator.PART PART ON PART.ID = AI.Affected_Id
                                        JOIN innovator.PART_BOM PART_BOM ON PART.ID = PART_BOM.SOURCE_ID
                                        JOIN innovator.PART Information_BOM ON Information_BOM.ID = PART_BOM.Related_Id
                                    --  JOIN 
                                    WHERE 
                                    SE.STATE = 'Released' and -- dk bawt buo
                                    SE.ITEM_NUMBER ='{ecn}'
                                ),
                                BOM_MOI AS (
                                    -- BOM mới
                                    SELECT  
                                        PART.KEYED_NAME AS BOM,
                                        PART_BOM.SORT_ORDER AS STT,
                                        Information_BOM.KEYED_NAME AS MaSP,
                                        Information_BOM.UNIT AS DV,
                                        PART_BOM.GTO_BASE_QTY AS MauSo,
                                        PART_BOM.GTO_LOSS AS TyLeHaoMon,
                                        PART_BOM.QUANTITY AS LuongDung

                                    from innovator.SIMPLE_ECO SE
                                    left JOIN innovator.SIMPLE_ECO_AFFECTED_ITEM SEAI ON SE.CONFIG_ID = SEAI.SOURCE_ID
                                    -- FROM innovator.SIMPLE_ECO_AFFECTED_ITEM SEAI
                                    -- JOIN innovator.SIMPLE_ECO SE ON SE.CONFIG_ID = SEAI.SOURCE_ID
                                    left JOIN innovator.AFFECTED_ITEM AI ON SEAI.RELATED_ID = AI.ID
                                        JOIN innovator.PART PART ON PART.ID = AI.NEW_ITEM_ID
                                        JOIN innovator.PART_BOM PART_BOM ON PART.ID = PART_BOM.SOURCE_ID
                                        JOIN innovator.PART Information_BOM ON Information_BOM.ID = PART_BOM.Related_Id
                                    WHERE 
                                    SE.STATE = 'Released' and 
                                    SE.ITEM_NUMBER ='{ecn}'

                                )

                                SELECT  
                                        COALESCE(C.[BOM], M.[BOM]) AS BOM_SP,

                                        -- COALESCE(C.STT, M.STT) AS TC004,
                                        -- COALESCE(C.MaSP, M.MaSP) AS TC005,
                                        -- TC007 LÀ NULL

                                        -- M.STT AS TC004,
                                        M.MaSP AS TC005,
                                        M.DV AS TC006,
                                        M.LuongDung AS TC008,
                                        M.MauSo AS TC009,
                                        ISNULL(M.TyLeHaoMon, N'0.000') AS TC010,

                                        -- CŨ
                                        -- C.STT AS TC104,
                                        C.MaSP AS TC105,
                                        C.DV AS TC106,
                                        C.LuongDung AS TC108,
                                        C.MauSo AS TC109,
                                        -- C.TyLeHaoMon AS TC110,
                                        ISNULL(C.TyLeHaoMon, N'0.000') AS TC110,



                                        -- C.[Quy Cach] AS [Quy Cach Cu],
                                        -- M.[Quy Cach] AS [Quy Cach Moi],
                                        CASE 
                                            WHEN C.MaSP IS NULL THEN N'NEW'
                                            WHEN M.MaSP IS NULL THEN N'DELETE'
                                            WHEN (C.LuongDung <> M.LuongDung 
                                                OR C.MauSo <> M.MauSo 
                                                OR C.TyLeHaoMon <> M.TyLeHaoMon)
                                                THEN N'CHANGE'
                                            ELSE N'KHÔNG ĐỔI'
                                        END AS TrangThai

                                    FROM BOM_CU C
                                    FULL OUTER JOIN BOM_MOI M
                                        ON C.MaSP = M.MaSP
                                    AND C.STT = M.STT

                                    WHERE 
                                        CASE 
                                            WHEN C.MaSP IS NULL THEN N'NEW'
                                            WHEN M.MaSP IS NULL THEN N'DELETE'
                                            WHEN (C.LuongDung <> M.LuongDung 
                                                OR C.MauSo <> M.MauSo 
                                                OR C.TyLeHaoMon <> M.TyLeHaoMon)
                                                THEN N'CHANGE'
                                            ELSE N'KHÔNG ĐỔI'
                                        END IN (
                                            N'NEW', 
                                            N'DELETE',
                                            N'CHANGE'
                                            )  
                                        and (M.[BOM] = '{MD001}' or C.[BOM] = '{MD001}')
                    ";

            using (SqlCommand cmd = new SqlCommand(sql_PLM_Get_BOMTC, plm))
            {
                // Nếu plm có transaction thì có thể truyền thêm transaction của PLM, nếu cần
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        // insert vào staging như bạn đang làm
                        using (SqlCommand insert = new SqlCommand(
                            @"INSERT INTO BOMTC_Staging_ERP (SyncStatus, CREATOR,	CREATE_DATE, FLAG,
                                TC001,	TC002,	TC003,	
                                TC004,	TC005,	TC006,	TC008,	TC009,	TC010,	
                                TC104,	TC105,	TC106,	TC108,	TC109,	TC110


                                )
                                 VALUES ( @SyncStatus, @CREATOR,	CONVERT(varchar(8),GETDATE(),112), @FLAG,
                                    @TC001,	@TC002,	@TC003,	
                                    @TC004,	@TC005,	@TC006,	@TC008,	@TC009,	@TC010,
                                    @TC104,	@TC105,	@TC106,	@TC108,	@TC109,	@TC110
                                )",
                              staging, stagingTran))
                        {
                            insert.Parameters.AddWithValue("@SyncStatus", "0");
                            insert.Parameters.AddWithValue("@CREATOR", creator);
                            insert.Parameters.AddWithValue("@FLAG", "1");

                            insert.Parameters.AddWithValue("@TC001", TC001);
                            insert.Parameters.AddWithValue("@TC002", TC002);
                            insert.Parameters.AddWithValue("@TC003", TC003);
                            //insert.Parameters.AddWithValue("@TC004", rd["TC004"] ?? DBNull.Value);
                            //listTC004.Add(rd["TC004"]?.ToString());

                            //insert.Parameters.AddWithValue("@TC004", rd["TC004"] == DBNull.Value ? DBNull.Value : int.Parse(rd["TC004"].ToString()).ToString("D4"));
                            //listTC004.Add(rd["TC004"] == DBNull.Value ? null : int.Parse(rd["TC004"].ToString()).ToString("D4"));

                            using (var tran = erp.BeginTransaction())
                            {
                                try
                                {
                                    if (rd["TrangThai"].Equals("NEW") )
                                    {
                                        string tc004 = GetTC004_new(erp, tran, MD001);
                                        insert.Parameters.AddWithValue("@TC004", tc004);

                                        insert.Parameters.AddWithValue("@TC104", "");
                                        listTC004.Add(tc004);
                                    }
                                    else if (rd["TrangThai"].Equals("CHANGE") )
                                    {
                                        string tc004 = GetTC004(erp, tran, MD001, rd["TC005"] ?? DBNull.Value);
                                        insert.Parameters.AddWithValue("@TC004", tc004);
                                        insert.Parameters.AddWithValue("@TC104", tc004);
                                        listTC004.Add(tc004);
                                    } else if (rd["TrangThai"].Equals("DELETE"))
                                    {
                                        string tc004 = GetTC004(erp, tran, MD001, rd["TC105"] ?? DBNull.Value);
                                        insert.Parameters.AddWithValue("@TC004", tc004);
                                        insert.Parameters.AddWithValue("@TC104", tc004);
                                        listTC004.Add(tc004);
                                    }

                                        tran.Commit();
                                }
                                catch
                                {
                                    tran.Rollback();
                                    throw;
                                    //return;
                                }
                            }

                            //    insert.Parameters.AddWithValue("@TC004", GetTC004(erp, stagingTran, TC001, rd["TC005"] ?? DBNull.Value));
                            //listTC004.Add(GetTC004(erp, stagingTran, TC001, rd["TC005"] ?? DBNull.Value));



                            insert.Parameters.AddWithValue("@TC005", rd["TC005"] ?? DBNull.Value);
                            insert.Parameters.AddWithValue("@TC006", rd["TC006"] ?? DBNull.Value);
                            insert.Parameters.AddWithValue("@TC008", rd["TC008"] ?? DBNull.Value);
                            insert.Parameters.AddWithValue("@TC009", rd["TC009"] ?? DBNull.Value);
                            insert.Parameters.AddWithValue("@TC010", rd["TC010"] ?? DBNull.Value);

                            //insert.Parameters.AddWithValue("@TC104", rd["TC104"] == DBNull.Value ? "" : int.Parse(rd["TC104"].ToString()).ToString("D4"));


                            insert.Parameters.AddWithValue("@TC105", rd["TC105"] == DBNull.Value ? "" : rd["TC105"]);
                            insert.Parameters.AddWithValue("@TC106", rd["TC106"] == DBNull.Value ? "" : rd["TC106"]);
                            insert.Parameters.AddWithValue("@TC108", rd["TC108"] == DBNull.Value ? "0" : rd["TC108"]);
                            insert.Parameters.AddWithValue("@TC109", rd["TC109"] == DBNull.Value ? "0" : rd["TC109"]);
                            insert.Parameters.AddWithValue("@TC110", rd["TC110"] ?? DBNull.Value);


                            insert.ExecuteNonQuery();
                        }
                    }
                }
            }
            foreach (var tc004 in listTC004)
            {
                Console.WriteLine(tc004);
                //string tc0041 = "0030";
                string sql_ERR_Get_BOMMD = $@"
                                    select 
                                    MD002 AS TC104,	
                                    MD003 AS TC105,	
                                    MD004 AS TC106,	
                                    MD005 AS TC107,	
                                    MD006 AS TC108,	
                                    MD007 AS TC109,	
                                    MD008 AS TC110,	
                                    MD009 AS TC111,	
                                    MD010 AS TC112,	
                                    MD011 AS TC113,	
                                    MD012 AS TC114,	
                                    MD013 AS TC115,	
                                    MD014 AS TC116,	
                                    MD015 AS TC117,	
                                    MD016 AS TC129,	
                                    MD017 AS TC119,	
                                    MD018 AS TC120,	
                                    MD019 AS TC121,	
                                    MD020 AS TC122,	
                                    MD021 AS TC123,	
                                    MD022 AS TC124,	
                                    MD023 AS TC125,	
                                    MD024 AS TC126,	
                                    MD025 AS TC127,	
                                    MD026 AS TC128,	
                                    MD027 AS TC130,	
                                    MD028 AS TC131,	
                                    MD029 AS TC132,	
                                    MD030 AS TC133,	
                                    MD031 AS TC134
                                    from BOMMD
                                    where TRIM(MD001) = TRIM(N'{MD001}') and MD002 = '{tc004}'                                  
                    ";
                using (SqlCommand cmdERP = new SqlCommand(sql_ERR_Get_BOMMD, erp))
                {
                    // Nếu plm có transaction thì có thể truyền thêm transaction của PLM, nếu cần
                    using (SqlDataReader rd1 = cmdERP.ExecuteReader())
                    {
                        if (!rd1.HasRows)
                        {
                            // CASE 1: KHÔNG CÓ DỮ LIỆU
                            //using (SqlCommand update = new SqlCommand(
                            //     @"UPDATE BOMTC_Staging_ERP SET
                            //            TC007='',   TC011=N'****',   TC012='',   TC013='', TC014='',
                            //            TC015='N',  TC016='Y',      TC017='',   TC018='', TC019=1,
                            //            TC020=0,   TC021='',       TC022='',   TC023='', TC024='',
                            //            TC025='',   TC026='',       TC027='',   TC028='', TC029='',
                            //            TC030=0,   TC031=0,       TC032='N',  TC033='', TC034='',
                            //            TC107='',   TC111='',       TC112='',   TC113='', TC114='',
                            //            TC115='',   TC116='',       TC117='',   TC119='', TC120='',
                            //            TC121='',   TC122='',       TC123='',   TC124='', TC125='',
                            //            TC126='',   TC127='',       TC128='',   TC129='', TC130='',
                            //            TC131='',   TC132='N',      TC133='',   TC134=''

                            //              WHERE TC001=@TC001 AND TC002=@TC002 AND TC003=@TC003 AND TC004=@TC004",
                            //    staging, stagingTran))
                            using (SqlCommand update = new SqlCommand(
                            @"UPDATE BOMTC_Staging_ERP SET
                                        TC011=N'****', 
                                        TC015='N',  
                                        TC016='Y',       
                                        TC032='N',  
                                        TC132='N',  
                                         TC019=1

                                          WHERE TC001=@TC001 AND TC002=@TC002 AND TC003=@TC003 AND TC004=@TC004", staging, stagingTran))
                            {
                                update.Parameters.AddWithValue("@TC001", TC001);
                                update.Parameters.AddWithValue("@TC002", TC002);
                                update.Parameters.AddWithValue("@TC003", TC003);
                                update.Parameters.AddWithValue("@TC004", tc004);

                                update.ExecuteNonQuery();
                            }
                        }
                        else
                        {


                            while (rd1.Read())
                            {
                                // insert vào staging như bạn đang làm
                                using (SqlCommand update = new SqlCommand(
                                                $@"UPDATE BOMTC_Staging_ERP SET
                                        TC007=@TC007, TC011=@TC011, TC012=@TC012, TC013=@TC013, TC014=@TC014,
                                        TC015=@TC015, TC016=@TC016, TC017=@TC017, TC018=@TC018, TC019=@TC019,
                                        TC020=@TC020, TC021=@TC021, TC022=@TC022, TC023=@TC023, TC024=@TC024,
                                        TC025=@TC025, TC026=@TC026, TC027=@TC027, TC028=@TC028, TC029=@TC029,
                                        TC030=@TC030, TC031=@TC031, TC032=@TC032, TC033=@TC033, TC034=@TC034,
                                        TC107=@TC107, TC111=@TC111, TC112=@TC112, TC113=@TC113, TC114=@TC114,
                                        TC115=@TC115, TC116=@TC116, TC117=@TC117, TC119=@TC119, TC120=@TC120,
                                        TC121=@TC121, TC122=@TC122, TC123=@TC123, TC124=@TC124, TC125=@TC125,
                                        TC126=@TC126, TC127=@TC127, TC128=@TC128, TC129=@TC129, TC130=@TC130,
                                        TC131=@TC131, TC132=@TC132, TC133=@TC133, TC134=@TC134
                                     WHERE TC001=@TC001 AND TC002=@TC002 AND TC003=@TC003 AND TC004=@TC004",
                                    staging, stagingTran))
                                {

                                    update.Parameters.AddWithValue("@TC001", TC001);
                                    update.Parameters.AddWithValue("@TC002", TC002);
                                    update.Parameters.AddWithValue("@TC003", TC003);
                                    update.Parameters.AddWithValue("@TC004", tc004);
                                    //update.Parameters.AddWithValue("@TC004", "0030");

                                    update.Parameters.AddWithValue("@TC007", rd1["TC107"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC011", rd1["TC111"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC012", rd1["TC112"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC013", rd1["TC113"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC014", rd1["TC114"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC015", rd1["TC115"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC016", rd1["TC116"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC017", rd1["TC117"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC018", ""); // NGUYÊN NHÂN
                                    update.Parameters.AddWithValue("@TC019", rd1["TC119"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC020", rd1["TC120"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC021", rd1["TC121"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC022", rd1["TC122"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC023", rd1["TC123"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC024", rd1["TC124"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC025", rd1["TC125"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC026", rd1["TC126"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC027", rd1["TC127"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC028", rd1["TC128"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC029", rd1["TC129"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC030", rd1["TC130"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC031", rd1["TC131"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC032", rd1["TC132"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC033", rd1["TC133"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC034", rd1["TC134"] ?? DBNull.Value);

                                    update.Parameters.AddWithValue("@TC107", rd1["TC107"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC111", rd1["TC111"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC112", rd1["TC112"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC113", rd1["TC113"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC114", rd1["TC114"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC115", rd1["TC115"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC116", rd1["TC116"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC117", rd1["TC117"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC119", rd1["TC119"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC120", rd1["TC120"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC121", rd1["TC121"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC122", rd1["TC122"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC123", rd1["TC123"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC124", rd1["TC124"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC125", rd1["TC125"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC126", rd1["TC126"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC127", rd1["TC127"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC128", rd1["TC128"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC129", rd1["TC129"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC130", rd1["TC130"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC131", rd1["TC131"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC132", rd1["TC132"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC133", rd1["TC133"] ?? DBNull.Value);
                                    update.Parameters.AddWithValue("@TC134", rd1["TC134"] ?? DBNull.Value);


                                    update.ExecuteNonQuery();
                                }
                            }
                        }
                    }
                }
            }
        }
        // =====================================================


        public static void UpdateBOMMC_FromBOMTB(SqlConnection erp, SqlTransaction tran, Dictionary<string, object> tb)
        {
            object nguoiThayDoi = tb.GetValueOrDefault("CREATOR") ?? DBNull.Value;
            //string nhomNguoiTao = GetMF004(erp, tran, nguoiTao);

            // Sử dụng cùng SQL update bạn đã có, nhưng bây giờ binding tham số từ tb
            object TB003_value = tb.GetValueOrDefault("TB003") ?? DBNull.Value;
            object TB004_value = tb.GetValueOrDefault("TB004") ?? DBNull.Value;
            object TB107_value = tb.GetValueOrDefault("TB107") ?? DBNull.Value; // phiên bản cũ

            string updateBOMMC = @"
                UPDATE M
                SET 
                    MODIFIER = @MODIFIER,
                    MODI_DATE = CONVERT(varchar(8), GETDATE(), 112),
                    M.MC002 = T.TB005,
                    M.MC003 = T.TB006, 
                    M.MC004 = T.TB008, 
                    M.MC005 = T.TB009, 
                    M.MC006 = T.TB001, 
                    M.MC007 = T.TB002, 
                    M.MC008 = T.TB003,
                    M.MC009 = T.TB007,
                    M.MC010 = T.TB013,         
                    M.MC011 = T.TB014, 
                    M.MC012 = T.TB015, 
                    M.MC013 = T.TB016, 
                    M.MC014 = T.TB017, 
                    M.MC015 = T.TB018
                FROM BOMMC M
                INNER JOIN BOMTB T
                    -- ON @TB004 = M.MC001 AND @TB107 = M.MC009
                    ON T.TB004 = M.MC001 AND T.TB107 = M.MC009
                WHERE T.TB004 = @TB004 AND T.TB107 = @TB107 AND T.TB003 = @TB003 AND T.TB012 = 'Y'";

            using (var cmd = new SqlCommand(updateBOMMC, erp, tran))
            {
                cmd.Parameters.AddWithValue("@MODIFIER", nguoiThayDoi);
                cmd.Parameters.AddWithValue("@TB003", TB003_value);
                cmd.Parameters.AddWithValue("@TB004", TB004_value);
                cmd.Parameters.AddWithValue("@TB107", TB107_value);
                int affected = cmd.ExecuteNonQuery();
                Console.WriteLine($"     Đã cập nhật {affected} dòng BOMMC dựa theo BOMTB.");
            }
        }

        public static void MergeBOMMD_FromBOMTC(SqlConnection erp, SqlTransaction tran, Dictionary<string, object> ta, Dictionary<string, object> tb, Dictionary<string, object> tc, string company)
        {
            // Dùng MERGE SQL đã có, chỉ bind param từ tc và thêm creator/nhom
            //object nguoiTao = tc.GetValueOrDefault("CREATOR") ?? ta.GetValueOrDefault("CREATOR") ?? DBNull.Value;
            object nguoiTao = tc.GetValueOrDefault("CREATOR") ?? DBNull.Value;
            string nhomNguoiTao = Helper.GetMF004(erp, tran, nguoiTao);

            object TC001_value = tc.GetValueOrDefault("TC001") ?? DBNull.Value;
            object TC002_value = tc.GetValueOrDefault("TC002") ?? DBNull.Value;
            object TC003_value = tc.GetValueOrDefault("TC003") ?? DBNull.Value;
            object TC004_value = tc.GetValueOrDefault("TC004") ?? DBNull.Value;

            string updateBOMMD = @"
                SET ARITHABORT ON;
                SET ANSI_WARNINGS ON;
                SET ANSI_NULLS ON;
                SET QUOTED_IDENTIFIER ON;
                SET CONCAT_NULL_YIELDS_NULL ON;
    /* =========================
       1. DELETE nếu TC004 NULL / rỗng
       ========================= */
    DELETE M
    FROM BOMMD M
    INNER JOIN BOMMC MC ON M.MD001 = MC.MC001 
    INNER JOIN BOMTC TC 
            ON TC.TC001 = MC.MC006
           AND TC.TC002 = MC.MC007
           AND TC.TC003 = MC.MC008
           AND M.MD002 = TC.TC004
    WHERE TC.TC001 = @TC001
      AND TC.TC002 = @TC002
      AND TC.TC003 = @TC003
      AND TC.TC004 = @TC004
      AND (TC.TC005 IS NULL OR LTRIM(RTRIM(TC.TC005)) = '');


                MERGE INTO BOMMD AS M
                USING (
                    SELECT 
                        TC.CREATE_DATE,
                        TC.TC001, TC.TC002, TC.TC003, TC.TC004,
                        TC.TC005, TC.TC006, TC.TC007, TC.TC008, TC.TC009, TC.TC010,
                        TC.TC011, TC.TC012, TC.TC013, TC.TC014, TC.TC015, TC.TC016,
                        TC.TC017, TC.TC019, TC.TC020, TC.TC021, TC.TC022, TC.TC023,
                        TC.TC024, TC.TC025, TC.TC026, TC.TC027, TC.TC028, TC.TC029,
                        TC.TC030, TC.TC031, TC.TC032, TC.TC033, TC.TC034,
                        MC001 
                    FROM BOMTC TC
                    INNER JOIN BOMMC ON TC.TC001 = BOMMC.MC006
                                     AND TC.TC002 = BOMMC.MC007
                                     AND TC.TC003 = BOMMC.MC008
                    WHERE TC.TC001 = @TC001 
                      AND TC.TC002 = @TC002 
                      AND TC.TC003 = @TC003 
                      AND TC.TC004 = @TC004
                    AND TC.TC005 IS NOT NULL
                    AND LTRIM(RTRIM(TC.TC005)) <> ''

                ) AS SRC
                ON (M.MD001 = SRC.MC001 AND M.MD002 = SRC.TC004)

                WHEN MATCHED THEN
                    UPDATE SET
                        M.MODIFIER = @MODIFIER,
                        M.MODI_DATE = CONVERT(varchar(8), GETDATE(), 112),
                        M.MD003 = SRC.TC005,
                        M.MD004 = SRC.TC006,
                        M.MD005 = SRC.TC007,
                        M.MD006 = SRC.TC008,
                        M.MD007 = SRC.TC009,
                        M.MD008 = SRC.TC010,
                        M.MD009 = SRC.TC011,
                        M.MD010 = SRC.TC012,
                        M.MD011 = SRC.TC013,
                        M.MD012 = SRC.TC014,
                        M.MD013 = SRC.TC015,
                        M.MD014 = SRC.TC016,
                        M.MD015 = SRC.TC017,
                        M.MD016 = SRC.TC029,
                        M.MD017 = SRC.TC019,
                        M.MD018 = SRC.TC020,
                        M.MD019 = SRC.TC021,
                        M.MD020 = SRC.TC022,
                        M.MD021 = SRC.TC023,
                        M.MD022 = SRC.TC024,
                        M.MD023 = SRC.TC025,
                        M.MD024 = SRC.TC026,
                        M.MD025 = SRC.TC027,
                        M.MD026 = SRC.TC028,
                        M.MD027 = SRC.TC030,
                        M.MD028 = SRC.TC031,
                        M.MD029 = SRC.TC032,
                        M.MD030 = SRC.TC033,
                        M.MD031 = SRC.TC034,
                        M.MD032 = 'Y'
                WHEN NOT MATCHED THEN
                    INSERT (COMPANY, CREATOR,USR_GROUP,CREATE_DATE,
                            MD001, MD002, MD003, MD004, MD005, MD006, MD007, MD008, MD009, MD010,
                            MD011, MD012, MD013, MD014, MD015, MD016, MD017, MD018, MD019, MD020,
                            MD021, MD022, MD023, MD024, MD025, MD026, MD027, MD028, MD029, MD030,
                            MD031, MD032)
                    VALUES (
                        @Cong_ty, @TAO,@NhonNguoiTao,CONVERT(varchar(8), GETDATE(), 112),
                        SRC.MC001, SRC.TC004, SRC.TC005, SRC.TC006, SRC.TC007, SRC.TC008, SRC.TC009, SRC.TC010, SRC.TC011, SRC.TC012,
                        SRC.TC013, SRC.TC014, SRC.TC015, SRC.TC016, SRC.TC017, 
                        SRC.TC029 + N'Thêm MS nguyên tố' + SRC.CREATE_DATE, 
                        SRC.TC019, SRC.TC020, SRC.TC021, SRC.TC022,
                        SRC.TC023, SRC.TC024, SRC.TC025, SRC.TC026, SRC.TC027, SRC.TC028, SRC.TC030, SRC.TC031, SRC.TC032, SRC.TC033,
                        SRC.TC034, 'Y'
                    );
                ";

            using (var cmd = new SqlCommand(updateBOMMD, erp, tran))
            {
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@Cong_ty", company);
                cmd.Parameters.AddWithValue("@TAO", nguoiTao ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@MODIFIER", nguoiTao ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@NhonNguoiTao", nhomNguoiTao ?? (object)DBNull.Value);

                cmd.Parameters.AddWithValue("@TC001", TC001_value ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@TC002", TC002_value ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@TC003", TC003_value ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@TC004", TC004_value ?? DBNull.Value);

                int affected = cmd.ExecuteNonQuery();
                Console.WriteLine($"      MERGE BOMMD affected {affected} rows.");
            }
        }




        public static string GetTC004(SqlConnection erp, SqlTransaction tran, object MD001, object MD003)
        {
            if (MD001 == null || MD001 == DBNull.Value || MD003 == null || MD003 == DBNull.Value) return null;

            //string sql = "SELECT MD002 FROM BOMMD WHERE MD001 = @MD001 and MD003 = @MD003";
            string sql = "SELECT MD002 FROM BOMMD WHERE TRIM(MD001) = TRIM(@MD001) and TRIM(MD003) = TRIM(@MD003)";
            using (var cmd = new SqlCommand(sql, erp, tran))
            {
                cmd.Parameters.AddWithValue("@MD001", MD001);
                cmd.Parameters.AddWithValue("@MD003", MD003);
                var r = cmd.ExecuteScalar();
                return r?.ToString();
            }
        }
        public static string GetTC004_new(SqlConnection erp, SqlTransaction tran, object MD001)
        {
            if (MD001 == null || MD001 == DBNull.Value) return null;
            string sql = "select RIGHT('0000' + CAST(MAX(MD002) + 10 AS VARCHAR(4)), 4) FROM BOMMD WHERE TRIM(MD001) = TRIM(@MD001)";
            using (var cmd = new SqlCommand(sql, erp, tran))
            {
                cmd.Parameters.AddWithValue("@MD001", MD001);
                var r = cmd.ExecuteScalar();
                return r?.ToString();
            }
        }


    }
}