﻿using System.Data;
using System.Data.SqlClient;



namespace Staging_ERP_TO_ERP_BOM_Change_Form
{    
    public class Helper
    {
        public static void InsertRow(SqlConnection erp, SqlTransaction tran, string table, Dictionary<string, object> data, HashSet<string> erpColumns, string company)
        {
            var common = new List<string>();
            foreach (var k in data.Keys)
            {
                if (k.Equals("SyncStatus", StringComparison.OrdinalIgnoreCase) || k.Equals("TransferredAt", StringComparison.OrdinalIgnoreCase) || k.Equals("CreatedAt", StringComparison.OrdinalIgnoreCase))
                    continue;

                if (erpColumns.Contains(k)) common.Add(k);
            }

            // đảm bảo có cột COMPANY
            if (!common.Any(c => c.Equals("COMPANY", StringComparison.OrdinalIgnoreCase)))
                common.Add("COMPANY");
            // NHOM CUA NGUOI TAO
            if (!common.Any(c => c.Equals("USR_GROUP", StringComparison.OrdinalIgnoreCase)))
                common.Add("USR_GROUP");

            string cols = string.Join(",", common);
            string vals = string.Join(",", common.Select(c => "@" + c));
            string insert = $"INSERT INTO {table} ({cols}) VALUES ({vals})";

            using (var cmd = new SqlCommand(insert, erp, tran))
            {
                foreach (var c in common)
                {
                    if (c.Equals("COMPANY", StringComparison.OrdinalIgnoreCase))
                        cmd.Parameters.AddWithValue("@COMPANY", company);
                    else if (c.Equals("USR_GROUP", StringComparison.OrdinalIgnoreCase))
                    {
                        //cmd.Parameters.AddWithValue("@USR_GROUP", GetMF004( data o nayf dduowjc  lấy từ ô Creator trong khu này luôn));
                        // Lấy Creator từ data

                        string? creator = data.ContainsKey("Creator") && data["Creator"] != null
                            ? data["Creator"].ToString()
                            : "";

                        // Gọi hàm lấy USR_GROUP theo Creator
                        string usrGroup = GetMF004(erp, tran, creator);

                        cmd.Parameters.AddWithValue("@USR_GROUP", (object)usrGroup ?? DBNull.Value);
                    }
                    else
                    {
                        object v = data.ContainsKey(c) ? data[c] ?? DBNull.Value : DBNull.Value;
                        cmd.Parameters.AddWithValue("@" + c, v);
                    }
                }


                cmd.ExecuteNonQuery();
            }
        }

        //#region Helpers
        // Đọc multiple rows trả về list of dictionary
        public static List<Dictionary<string, object>> ReadRows(SqlConnection conn, string sql, Dictionary<string, object> parameters = null)
        {
            var list = new List<Dictionary<string, object>>();
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                {
                    foreach (var p in parameters)
                        cmd.Parameters.AddWithValue(p.Key, p.Value ?? DBNull.Value);
                }

                using (var reader = cmd.ExecuteReader())
                {
                    var schema = reader.GetSchemaTable();
                    while (reader.Read())
                    {
                        var d = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                        foreach (DataRow r in schema.Rows)
                        {
                            string col = r["ColumnName"].ToString();
                            d[col] = reader[col];
                        }
                        list.Add(d);
                    }
                }
            }
            return list;
        }

        // láy tên cột từ các bảng
        public static HashSet<string> GetTableColumns(SqlConnection conn, string tableName)
        {
            var columns = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string query = $"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{tableName}'";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    columns.Add(reader.GetString(0));
                }
            }
            return columns;
        }

        // cập nhật trag thái thất bại cho ECB_TEST
        public static void TransferFailed(SqlConnection staging, string stagingTable, string ecn, string trangThai)
        {
            // Nếu matchColumnsForWhere không truyền, dùng tất cả keys làm điều kiện

            string sql = $"UPDATE {stagingTable} SET SyncStatus = {trangThai} WHERE ECN = @ECN";

            using (var cmd = new SqlCommand(sql, staging))
            {
                cmd.Parameters.AddWithValue("@ECN", ecn);

                int affected = cmd.ExecuteNonQuery();
                Console.WriteLine($"    Cap Nhap SyncStatus thất bại cho {ecn}.");
            }
        }


        public static void UpdateStagingSyncStatus(SqlConnection staging, string stagingTable, Dictionary<string, object> keyValues, List<string> matchColumnsForWhere = null)
        {
            // Nếu matchColumnsForWhere không truyền, dùng tất cả keys làm điều kiện
            var whereCols = matchColumnsForWhere ?? keyValues.Keys.ToList();
            string where = string.Join(" AND ", whereCols.Select(c => c + " = @" + c));
            string sql = $"UPDATE {stagingTable} SET SyncStatus = 1, TransferredAt = SYSDATETIME() WHERE " + where;

            using (var cmd = new SqlCommand(sql, staging))
            {
                foreach (var c in whereCols)
                    cmd.Parameters.AddWithValue("@" + c, keyValues.ContainsKey(c) ? keyValues[c] ?? DBNull.Value : DBNull.Value);

                int affected = cmd.ExecuteNonQuery();
                //Console.WriteLine($"    🔁 Cập nhật SyncStatus cho {affected} dòng trong {stagingTable} (WHERE {where}).");
                Console.WriteLine($"    Cap Nhap SyncStatus cho {affected} dong trong {stagingTable}.");
            }
        }


        public static string GetMF004(SqlConnection erp, SqlTransaction tran, object mf001)
        {
            if (mf001 == null || mf001 == DBNull.Value) return null;
            string sql = "SELECT MF004 FROM ADMMF WHERE MF001 = @MF001";
            using (var cmd = new SqlCommand(sql, erp, tran))
            {
                cmd.Parameters.AddWithValue("@MF001", mf001);
                var r = cmd.ExecuteScalar();
                return r?.ToString();
            }
        }
    }
}

