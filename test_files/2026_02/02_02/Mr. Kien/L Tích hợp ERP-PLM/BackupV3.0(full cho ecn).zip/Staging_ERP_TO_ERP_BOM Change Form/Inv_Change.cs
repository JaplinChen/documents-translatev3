﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;



namespace Staging_ERP_TO_ERP_BOM_Change_Form
{
    public class Inv_Change
    {
        // THỰC HIỆN TOÀN BỘ QUÁ TRÌNH TỪ TAOOJ PHIẾU BOMI02 ĐẾN LÚC ĐIỀN DỮ LIỆU VÀO BẢNG BOM CỦA ERP BOMMC VÀ BOMMD
        public static void Inv_change(SqlConnection erp, SqlConnection plm, SqlConnection staging, string ecn, string creator, string company, ref bool success)
        {

            ////viết hàm truyền dữ liệu vào bảng INVTL_Staging_ERP, INVTM_Staging_ERP
            //using (var tran = staging.BeginTransaction())
            //{
            //    // truyền vào bảng trung gian
            //    try
            //    {

            //        Insert_INVTL_INVTM_Staging_ERP(plm, erp, staging, tran, ecn, creator, company);
            //    }
            //    catch (Exception ex)
            //    {
            //        //tran.Rollback();
            //        return:
            //    }
            //    tran.Commit();

            //}

            // =====================================================================================
            // bỏ sung insert into vào bảng kia

            // Lấy danh sách cột bảng ERP 1 lần cho các bảng cần dùng
            var colsINVTL = Helper.GetTableColumns(erp, "INVTL");
            var colsINVTM = Helper.GetTableColumns(erp, "INVTM");


            // Đọc từng record INVTL_Staging_ERP chưa sync
            string selectTL = @$"SELECT * FROM INVTL_Staging_ERP  WHERE SyncStatus = 0 and TRIM(TL010)  = trim(N'{ecn}')";
            var tlRows = Helper.ReadRows(staging, selectTL);

            int totalTL = 0;
            foreach (var tl in tlRows)
            {
                totalTL++;
                object TL001 = tl.GetValueOrDefault("TL001") ?? DBNull.Value;
                object TL004 = tl.GetValueOrDefault("TL004") ?? DBNull.Value;

                Console.WriteLine($"\n (INVTL) Xu ly TL001={TL001.ToString().Trim()}, TL004={TL004} ...");

                using (var tran = erp.BeginTransaction())
                {
                    try
                    {
                        // Insert BOMTA from BOMTA_Staging_ERP
                        try
                        {
                            Helper.InsertRow(erp, tran, "INVTL", tl, colsINVTL, company);
                            UpdateINVMB(erp, tran, tl, "INVTL", tl.GetValueOrDefault("TL004").ToString());
                        }
                        catch (Exception ex)
                        {
                            Helper.TransferFailed(staging, "ECN_Test", ecn, "2");
                            //success = false;
                            throw;
                        }
                        // Cập nhật TL
                        Helper.UpdateStagingSyncStatus(staging, "INVTL_Staging_ERP", new Dictionary<string, object> { { "TL001", TL001.ToString() }, { "TL004", TL004 } });

                        // Gọi Sync INVTM theo TL
                        var tmRows = Helper.ReadRows(staging, "SELECT * FROM INVTM_Staging_ERP WHERE TM001 = @TM001 AND TM002 = @TM002 AND SyncStatus = 0",
                            new Dictionary<string, object> { { "@TM001", TL001 }, { "@TM002", TL004 } });

                        int tmCount = 0;
                        foreach (var tm in tmRows)
                        {
                            tmCount++;
                            object TM001 = tm.GetValueOrDefault("TM001") ?? DBNull.Value;
                            object TM002 = tm.GetValueOrDefault("TM002") ?? DBNull.Value;
                            object TM003 = tm.GetValueOrDefault("TM003") ?? DBNull.Value;

                            Console.WriteLine($"   (BOMTB) Xu ly TM001={TM001}, TM002={TM002}, TM003={TM003} ...");

                            // Insert INVTM
                            try
                            {


                                Helper.InsertRow(erp, tran, "INVTM", tm, colsINVTM, company);
                                UpdateINVMB(erp, tran, tm, "INVTM", tm.GetValueOrDefault("TM002").ToString());
                            }
                            catch (Exception ex)
                            {
                                Helper.TransferFailed(staging, "ECN_Test", ecn, "2");

                                //success = false;
                                throw;
                            }
                            // Cập nhật TB
                            Helper.UpdateStagingSyncStatus(staging, "INVTM_Staging_ERP", new Dictionary<string, object> { { "TM001", TM001 }, { "TM002", TM002 }, { "TM003", TM003 } }, matchColumnsForWhere: new List<string> { "TM001", "TM002", "TM003" });


                        }

                        // Nếu tất cả thành công trong transaction thì commit
                        tran.Commit();

                        Console.WriteLine($" Hoan tat phieu INVTL TL001={TL001}, TL004={TL004}, TB_Rows={tmRows.Count}.");
                    }

                    catch (Exception ex)
                    {
                        success = false;
                        try { tran.Rollback(); } catch { }
                        Console.WriteLine("❌ Loi khi xu ly phieu INVTL - rollback: " + ex.Message);
                    }

                    // Nếu cần, ghi log chi tiết hoặc push thông báo
                }
            }
            if (success == true) Console.WriteLine($"\n=== HOAN TAT - Da xy ly {totalTL} DON THAY DOI INVTL ");



        }

        public static void Insert_INVTL_INVTM_Staging_ERP(SqlConnection plm, SqlConnection erp, SqlConnection staging, SqlTransaction stagingTran, string ecn, string creator, string company)
        {
            string sql_check_inv_change_check = @$"WITH SP_CU AS (
                    SELECT  
                    PART.ITEM_NUMBER as [MaSP],
                    PART.NAME as MB002,
                    PART.GTO_SPECIFICATION as MB003,


                    PART.MAKE_BUY as MB025,
                    PART.[DESCRIPTION] AS MB028,
                    PART.GTO_PROCESS AS MB068

                    from innovator.SIMPLE_ECO SE
                    left JOIN innovator.SIMPLE_ECO_AFFECTED_ITEM SEAI ON SE.CONFIG_ID = SEAI.SOURCE_ID
                    left JOIN innovator.AFFECTED_ITEM AI ON SEAI.RELATED_ID = AI.ID
                        JOIN innovator.PART PART ON PART.ID = AI.Affected_Id

                    WHERE 
                    SE.STATE = 'Released' and -- dk bawt buo
                    SE.ITEM_NUMBER = '{ecn}'
                ),
                SP_MOI AS (
                    SELECT  
                        PART.ITEM_NUMBER as [MaSP],
                        PART.NAME as MB002,
                        PART.GTO_SPECIFICATION as MB003,


                        PART.MAKE_BUY as MB025,
                        PART.[DESCRIPTION] AS MB028,
                        PART.GTO_PROCESS AS MB068

                    from innovator.SIMPLE_ECO SE
                    left JOIN innovator.SIMPLE_ECO_AFFECTED_ITEM SEAI ON SE.CONFIG_ID = SEAI.SOURCE_ID
                    left JOIN innovator.AFFECTED_ITEM AI ON SEAI.RELATED_ID = AI.ID
                        JOIN innovator.PART PART ON PART.ID = AI.NEW_ITEM_ID

                    WHERE 
                    SE.STATE = 'Released' and 
                    SE.ITEM_NUMBER = '{ecn}'
                )

                SELECT  
                        COALESCE(C.[MaSP], M.[MaSP]) AS Ma_SP,

                        C.MB002 AS TL002,
                        C.MB003 AS TL003,
                        C.MB025 AS MB025_OLD,
                        C.MB028 AS MB028_OLD,
                        C.MB068 AS MB068_OLD,

                        M.MB002 AS TL007,
                        M.MB003 AS TL008,
                        M.MB025 AS MB025_NEW,
                        M.MB028 AS MB028_NEW,
                        M.MB068 AS MB068_NEW,

                        CONCAT(
                            CASE WHEN ISNULL(C.MB002,'') <> ISNULL(M.MB002,'') THEN '1' ELSE '0' END,
                            CASE WHEN ISNULL(C.MB003,'') <> ISNULL(M.MB003,'') THEN '1' ELSE '0' END,
                            CASE WHEN ISNULL(C.MB025,'') <> ISNULL(M.MB025,'') THEN '1' ELSE '0' END,
                            CASE WHEN ISNULL(C.MB028,'') <> ISNULL(M.MB028,'') THEN '1' ELSE '0' END,
                            CASE WHEN ISNULL(C.MB068,'') <> ISNULL(M.MB068,'') THEN '1' ELSE '0' END
                        ) AS TrangThaiNhiPhan
                    FROM SP_CU C
                    FULL OUTER JOIN SP_MOI M
                        ON C.MaSP = M.MaSP

                    WHERE
                        (CASE WHEN ISNULL(C.MB002,'') <> ISNULL(M.MB002,'') THEN 1 ELSE 0 END)
                        + (CASE WHEN ISNULL(C.MB003,'') <> ISNULL(M.MB003,'') THEN 1 ELSE 0 END)
                        + (CASE WHEN ISNULL(C.MB025,'') <> ISNULL(M.MB025,'') THEN 1 ELSE 0 END)
                        + (CASE WHEN ISNULL(C.MB028,'') <> ISNULL(M.MB028,'') THEN 1 ELSE 0 END)
                        + (CASE WHEN ISNULL(C.MB068,'') <> ISNULL(M.MB068,'') THEN 1 ELSE 0 END)
                        > 0";


            using (SqlCommand cmd = new SqlCommand(sql_check_inv_change_check, plm))
            {
                // Nếu plm có transaction thì có thể truyền thêm transaction của PLM, nếu cần
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {                        
                        string TL001_OR_TM001 = rd["Ma_SP"].ToString();
                        string trangThai = rd["TrangThaiNhiPhan"].ToString(); 


                        using (var erpTran = erp.BeginTransaction())
                        {
                            try
                            {
                                string TL004_OR_TM003 = GetTL004_TM003(erp, erpTran, TL001_OR_TM001);

                                // INVTL THÊM với TL001_OR_TM001 và cần lấy phiên bản thay đổi cần phải làm ???
                                // ========================================
                                Insert_INVTL_Staging_ERP(plm, erp, staging, stagingTran, ecn, creator, company, TL001_OR_TM001, TL004_OR_TM003, 
                                    rd, erpTran);
                                //=========================================

                                                                
                                // ========================================
                                Insert_INVTM_Staging_ERP(plm, erp, staging, stagingTran, ecn, creator, company, TL001_OR_TM001, TL004_OR_TM003, 
                                    trangThai,rd, erpTran);
                                //=========================================

                                erpTran.Commit();
                            }
                            catch
                            {
                                erpTran.Rollback();
                                //return:
                                throw;
                            }
                        }




                    }
                }
            }

        }

        public static void Insert_INVTL_Staging_ERP(SqlConnection plm, SqlConnection erp, SqlConnection staging, SqlTransaction stagingTran, string ecn, string creator, string company, string TL001, string TL004
            , SqlDataReader rd, SqlTransaction erpTran)
        {
            // INVTM THÊM
            // total_TM003.ToString("D4") chuyern int qua thành hẹ nhị phân 0001,0002, 0003, 0004

            // Chuyển string → int
            int INT_TM023 = int.Parse(TL004) - 1;

            // Format lại thành 4 ký tự
            string STRING_TM023 = INT_TM023.ToString("D4");
            using (SqlCommand insert = new SqlCommand(@"                 
                                INSERT INTO INVTL_Staging_ERP (SyncStatus, CREATOR,	CREATE_DATE, FLAG,
                                TL001,	TL002,	TL003,  TL004,
                                TL005,  TL006,
                                TL007,	TL008,  TL009,  TL010, TL011, TL012 ,
                                TL013,
                                TL014,TL023


                                )
                                 VALUES ( @SyncStatus, @CREATOR,	CONVERT(varchar(8),GETDATE(),112), @FLAG,
                                @TL001,	@TL002,	@TL003, @TL004,
                                CONVERT(varchar(8),GETDATE(),112),	@TL006,
                                @TL007, @TL008,  @TL009,  @TL010, @TL011, @TL012 ,
                                CONVERT(varchar(8),GETDATE(),112),
                                @TL014,@TL023
                                )",
                staging, stagingTran))
            {
                insert.Parameters.AddWithValue("@SyncStatus", "0");
                insert.Parameters.AddWithValue("@CREATOR", creator);
                insert.Parameters.AddWithValue("@FLAG", "1");

                insert.Parameters.AddWithValue("@Tl001", TL001);
                insert.Parameters.AddWithValue("@Tl002", Get_Information(erp, erpTran, TL001, "MB002"));
                insert.Parameters.AddWithValue("@Tl003", Get_Information(erp, erpTran, TL001, "MB003"));
                insert.Parameters.AddWithValue("@Tl004", TL004);

                //insert.Parameters.AddWithValue("@TL005", "TTính SP");
                insert.Parameters.AddWithValue("@TL006", "N");

                insert.Parameters.AddWithValue("@TL007", rd["TL007"] ?? DBNull.Value);
                insert.Parameters.AddWithValue("@TL008", rd["TL008"] ?? DBNull.Value);
                insert.Parameters.AddWithValue("@TL009", creator);
                insert.Parameters.AddWithValue("@TL010", ecn);
                insert.Parameters.AddWithValue("@TL011", "0");
                insert.Parameters.AddWithValue("@TL012", creator);

                insert.Parameters.AddWithValue("@TL014", "Y");
                insert.Parameters.AddWithValue("@TL023", STRING_TM023);

                //foreach (SqlParameter p in insert.Parameters)
                //{
                //    Console.WriteLine(
                //        $"{p.ParameterName} = {p.Value} | Type = {p.Value?.GetType()}"
                //    );
                //}

                insert.ExecuteNonQuery();
            }

        }
        public static void Insert_INVTM_Staging_ERP(SqlConnection plm, SqlConnection erp, SqlConnection staging, SqlTransaction stagingTran, string ecn, string creator, string company, string TM001, string TM002, string trangThai,
            SqlDataReader rd, SqlTransaction erpTran)
        {
            int total_TM003 = 0;
            bool mb025Changed = trangThai[2] == '1';
            bool mb028Changed = trangThai[3] == '1';
            bool mb068Changed = trangThai[4] == '1';

            if (mb025Changed)
            {
                total_TM003++;
                // INVTM THÊM
                // total_TM003.ToString("D4") chuyern int qua thành hẹ nhị phân 0001,0002, 0003, 0004
                using (SqlCommand insert = new SqlCommand(@"                 
                            INSERT INTO INVTM_Staging_ERP (SyncStatus, CREATOR,	CREATE_DATE, FLAG,
                                TM001,	TM002,	TM003,  TM004,
                                TM005,	TM006,	TM007,	TM010,  TM013,
                                TM014
,  TM015
                                )

                            VALUES ( @SyncStatus, @CREATOR,	CONVERT(varchar(8),GETDATE(),112), @FLAG,
                                @TM001,	@TM002,	@TM003, @TM004,
                                @TM005,	@TM006,	@TM007,	@TM010,  @TM013,
                                @TM014
, @TM015
                                )",
                    staging, stagingTran))
                {
                    insert.Parameters.AddWithValue("@SyncStatus", "0");
                    insert.Parameters.AddWithValue("@CREATOR", creator);
                    insert.Parameters.AddWithValue("@FLAG", "1");

                    insert.Parameters.AddWithValue("@TM001", TM001);
                    insert.Parameters.AddWithValue("@TM002", TM002);
                    insert.Parameters.AddWithValue("@TM003", total_TM003.ToString("D4"));


                    insert.Parameters.AddWithValue("@TM004", "MB025");
                    insert.Parameters.AddWithValue("@TM005", "TTính SP");

                    insert.Parameters.AddWithValue("@TM006", rd["MB025_NEW"] ?? DBNull.Value);

                    insert.Parameters.AddWithValue("@TM007", Get_Information(erp, erpTran, TM001, "MB025"));
                    insert.Parameters.AddWithValue("@TM010", "V");
                    insert.Parameters.AddWithValue("@TM013", "Y");


                    insert.Parameters.Add("@TM014", SqlDbType.NVarChar, 50).Value =
                        rd["MB025_NEW"] == DBNull.Value
                            ? (object)DBNull.Value
                            : MapLoai(Convert.ToString(rd["MB025_NEW"]));


                    insert.Parameters.Add("@TM015", SqlDbType.NVarChar, 50).Value =
                        rd["MB025_OLD"] == DBNull.Value
                            ? (object)DBNull.Value
                            : MapLoai(Get_Information(erp, erpTran, TM001, "MB025"));

                    //foreach (SqlParameter p in insert.Parameters)
                    //{
                    //    Console.WriteLine(
                    //        $"{p.ParameterName} = {p.Value} | Type = {p.Value?.GetType()}"
                    //    );
                    //}
                    insert.ExecuteNonQuery();
                }
            }

            if (mb028Changed)
            {
                total_TM003++;
                // INVTM THÊM
                // total_TM003.ToString("D4") chuyern int qua thành hẹ nhị phân 0001,0002, 0003, 0004
                using (SqlCommand insert = new SqlCommand(@"                 
                            INSERT INTO INVTM_Staging_ERP (SyncStatus, CREATOR,	CREATE_DATE, FLAG,
                                TM001,	TM002,	TM003,  TM004,
                                TM005,	TM006,	TM007,	TM010,  TM013,
                                TM014
,  TM015
                                )

                            VALUES ( @SyncStatus, @CREATOR,	CONVERT(varchar(8),GETDATE(),112), @FLAG,
                                @TM001,	@TM002,	@TM003, @TM004,
                                @TM005,	@TM006,	@TM007,	@TM010,  @TM013,
                                @TM014
, @TM015
                                )",
                    staging, stagingTran))
                {
                    insert.Parameters.AddWithValue("@SyncStatus", "0");
                    insert.Parameters.AddWithValue("@CREATOR", creator);
                    insert.Parameters.AddWithValue("@FLAG", "1");

                    insert.Parameters.AddWithValue("@TM001", TM001);
                    insert.Parameters.AddWithValue("@TM002", TM002);
                    insert.Parameters.AddWithValue("@TM003", total_TM003.ToString("D4"));


                    insert.Parameters.AddWithValue("@TM004", "MB028");
                    insert.Parameters.AddWithValue("@TM005", "Ghi chú");
                    insert.Parameters.AddWithValue("@TM006", rd["MB028_NEW"] ?? DBNull.Value);
                    insert.Parameters.AddWithValue("@TM007", Get_Information(erp, erpTran, TM001, "MB028"));
                    insert.Parameters.AddWithValue("@TM010", "V");
                    insert.Parameters.AddWithValue("@TM013", "Y");


                    insert.Parameters.AddWithValue("@TM014", rd["MB028_NEW"] ?? DBNull.Value);
                    insert.Parameters.AddWithValue("@TM015", Get_Information(erp, erpTran, TM001, "MB028"));

                    //foreach (SqlParameter p in insert.Parameters)
                    //{
                    //    Console.WriteLine(
                    //        $"{p.ParameterName} = {p.Value} | Type = {p.Value?.GetType()}"
                    //    );
                    //}
                    insert.ExecuteNonQuery();
                }
            } 
            if (mb068Changed)
            {
                total_TM003++;
                // INVTM THÊM
                // total_TM003.ToString("D4") chuyern int qua thành hẹ nhị phân 0001,0002, 0003, 0004
                using (SqlCommand insert = new SqlCommand(@"                 
                            INSERT INTO INVTM_Staging_ERP (SyncStatus, CREATOR,	CREATE_DATE, FLAG,
                                TM001,	TM002,	TM003,  TM004,
                                TM005,	TM006,	TM007,	TM010,  TM013,
                                TM014
,  TM015
                                )

                            VALUES ( @SyncStatus, @CREATOR,	CONVERT(varchar(8),GETDATE(),112), @FLAG,
                                @TM001,	@TM002,	@TM003, @TM004,
                                @TM005,	@TM006,	@TM007,	@TM010,  @TM013,
                                @TM014
, @TM015
                                )",
                    staging, stagingTran))
                {
                    insert.Parameters.AddWithValue("@SyncStatus", "0");
                    insert.Parameters.AddWithValue("@CREATOR", creator);
                    insert.Parameters.AddWithValue("@FLAG", "1");

                    insert.Parameters.AddWithValue("@TM001", TM001);
                    insert.Parameters.AddWithValue("@TM002", TM002);
                    insert.Parameters.AddWithValue("@TM003", total_TM003.ToString("D4"));


                    insert.Parameters.AddWithValue("@TM004", "MB068");
                    insert.Parameters.AddWithValue("@TM005", "DCSX");
                    insert.Parameters.AddWithValue("@TM006", rd["MB068_NEW"] ?? DBNull.Value);
                    insert.Parameters.AddWithValue("@TM007", Get_Information(erp, erpTran, TM001, "MB068"));
                    insert.Parameters.AddWithValue("@TM010", "V");
                    insert.Parameters.AddWithValue("@TM013", "Y");


                    //insert.Parameters.AddWithValue("@TM014", Get_DCSX(erp, erpTran, rd["MB068_NEW"].ToString()));

                    //insert.Parameters.AddWithValue("@TM015", Get_DCSX(erp, erpTran, rd["MB068_OLD"].ToString()));


                    insert.Parameters.Add("@TM014", SqlDbType.NVarChar, 50).Value =
                        rd["MB068_NEW"] == DBNull.Value
                            ? (object)DBNull.Value
                            : Get_DCSX(erp, erpTran, rd["MB068_NEW"].ToString());

                    insert.Parameters.Add("@TM015", SqlDbType.NVarChar, 50).Value =
                        rd["MB068_OLD"] == DBNull.Value
                            ? (object)DBNull.Value
                            : Get_DCSX(erp, erpTran, Get_Information(erp, erpTran, TM001, "MB068"));



                    //foreach (SqlParameter p in insert.Parameters)
                    //{
                    //    Console.WriteLine(
                    //        $"{p.ParameterName} = {p.Value} | Type = {p.Value?.GetType()}"
                    //    );
                    //}
                    insert.ExecuteNonQuery();
                }
            }

        }

        // hàm update
        public static void UpdateINVMB(SqlConnection erp, SqlTransaction erpTran, Dictionary<string, object> noiDung, string check, string MB165)
        {
            object nguoiThayDoi = noiDung.GetValueOrDefault("CREATOR") ?? DBNull.Value;
            string updateINVMB = "";
            if (check == "INVTL")
            {
                string MB001_value = noiDung.GetValueOrDefault("TL001").ToString();

                string MB002_value = noiDung.GetValueOrDefault("TL007").ToString();
                string MB003_value = noiDung.GetValueOrDefault("TL008").ToString();

                updateINVMB = @$"
                UPDATE M
                SET 
                    MODIFIER = @MODIFIER,
                    MODI_DATE = CONVERT(varchar(8), GETDATE(), 112),
                    
                    M.MB002 = N'{MB002_value}',
                    M.MB003 = N'{MB003_value}', 
                    M.MB165 = N'{MB165}',
                    M.MB127 = N'1'
                FROM INVMB M
                WHERE TRIM(M.MB001) = TRIM(N'{MB001_value}')";
            }
            if (check == "INVTM")
            {
                string MB001_value = noiDung.GetValueOrDefault("TM001").ToString();
                string maCot = noiDung.GetValueOrDefault("TM004").ToString();
                string valueCot = noiDung.GetValueOrDefault("TM006").ToString();

                updateINVMB = @$"
                UPDATE M
                SET 
                    MODIFIER = @MODIFIER,
                    MODI_DATE = CONVERT(varchar(8), GETDATE(), 112),                    
                    M.{maCot} = N'{valueCot}',
                    M.MB165 = N'{MB165}',
                    M.MB127 = N'1'

                FROM INVMB M
                WHERE TRIM(M.MB001) = TRIM(N'{MB001_value}')";

            }


            using (var cmd = new SqlCommand(updateINVMB, erp, erpTran))
            {
                cmd.Parameters.AddWithValue("@MODIFIER", nguoiThayDoi);
                int affected = cmd.ExecuteNonQuery();
                //Console.WriteLine($"     Đã cập nhật {affected} dòng BOMMC dựa theo BOMTB.");
            }
        }


        //HelperS
        public static string GetTL004_TM003(SqlConnection erp, SqlTransaction tran, object TM001_OR_TL001)
        {
            if (TM001_OR_TL001 == null || TM001_OR_TL001 == DBNull.Value) return null;
            string sql = "select RIGHT('0000' + CAST(MAX(TL004) + 1 AS VARCHAR(4)), 4) FROM INVTL WHERE TRIM(TL001) = TRIM(@TM001_OR_TL001) AND TL014 = 'Y'";
            using (var cmd = new SqlCommand(sql, erp, tran))
            {
                cmd.Parameters.AddWithValue("@TM001_OR_TL001", TM001_OR_TL001);
                
                var r = cmd.ExecuteScalar();
                return r == DBNull.Value ? "0001" : r?.ToString();
            }
        }


        public static string Get_DCSX(SqlConnection erp, SqlTransaction tran, object MD001)
        {
            if (MD001 == "" || MD001 == null || MD001 == DBNull.Value) return "";
            string sql = "select MD002 FROM CMSMD WHERE TRIM(MD001) = TRIM(@MD001) ";
            using (var cmd = new SqlCommand(sql, erp, tran))
            {
                cmd.Parameters.AddWithValue("@MD001", MD001);
                var r = cmd.ExecuteScalar();
                return r?.ToString();
            }
        }


        public static string Get_Information(SqlConnection erp, SqlTransaction tran, object MB001,object Row)
        {
            if (MB001 == "" || MB001 == null || MB001 == DBNull.Value) return "";
            string sql = @$"select {Row} FROM INVMB WHERE TRIM(MB001) = TRIM(@MB001) ";
            using (var cmd = new SqlCommand(sql, erp, tran))
            {
                cmd.Parameters.AddWithValue("@MB001", MB001);
                var r = cmd.ExecuteScalar();
                return r?.ToString();
            }
        }
        private static string MapLoai(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            return value switch
            {
                "P" => "Mua",
                "M" => "Tự chế",
                "S" => "Ủy thác",
                "Y" => "Mã SP giả thiết",
                "F" => "Feature",
                "O" => "Option",
                _ => value   // fallback
            };
        }




    }
}

