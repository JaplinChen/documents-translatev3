﻿using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices;




namespace Staging_ERP_TO_ERP_BOM_Change_Form
{
    // // Phương án 2: xử lý truyền qua them từng đơn 1 (ví dụ: check đơn BOMTA xong nối qua BOMTB rồi qua BOMTC rồi mới chuyển qua đơn khác)
    class Program
    {
        static void Main(string[] args)
        {
            while (true) 
            {

                Thread.Sleep(10000); // 10 giây = 10.000 ms
                string company = "TEST2024"; // CỘT CONPANY

                string test = "Server=192.168.20.7;Database=WorkAssignmentForm;User Id=sa;Password=Vpic1@2024;";




                string PLMConnStr = "Server=192.168.20.32;Database=Test-Chạy thử;User Id=sa;Password=Vpic1@2024;";
                //string PLMConnStr = "Server=192.168.20.32;Database=Test-2025;User Id=sa;Password=Vpic1@2024;";

                string stagingConnStr = "Server=192.168.20.32;Database=PLM_ERP_TEST;User Id=sa;Password=Vpic1@2024;";

                string erpConnStr = "Server=192.168.20.201;Database=TEST2024;User Id=sa;Password=dsc@123;";

                Console.WriteLine("TRUYEN DU LIEU PHIEU THAY DOI DA XAC NHAN TU ERP TRUNG GIAN VE ERP\n");


                try
                {
                    using (var test_sai = new SqlConnection(test))
                    using (var staging = new SqlConnection(stagingConnStr))
                    using (var erp = new SqlConnection(erpConnStr))
                    using (var plm = new SqlConnection(PLMConnStr))
                    {
                        try
                        {
                            staging.Open();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("Unable to connect to STAGING DB", ex);
                        }

                        try
                        {
                            erp.Open();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("Unable to connect to ERP DB", ex);
                        }

                        try
                        {
                            plm.Open();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("Unable to connect to PLM DB", ex);
                        }


                        string selectECN = "SELECT top(10) * FROM ECN_Test WHERE SyncStatus = 0 order BY ECN ASC";
                        var ECN_Rows = Helper.ReadRows(staging, selectECN);
                        int total_ECN = 0;
                        foreach (var ecn in ECN_Rows)
                        {
                            bool success = true;
                            int loaiPhieuDoi = 410;
                            long maPhieuDoi = 0;
                            //viết hàm truyền dữ liệu vào bảng INVTL_Staging_ERP, INVTM_Staging_ERP
                            using (var tran = staging.BeginTransaction())
                            {
                                // truyền vào bảng trung gian
                                try
                                {
                                    if (ecn["Inv_Change"].ToString() == "1")
                                    {
                                        Inv_Change.Insert_INVTL_INVTM_Staging_ERP(plm, erp, staging, tran, ecn["ECN"].ToString(), ecn["CREATOR"].ToString(), company);
                                    }
                                    if (ecn["Bom_Change"].ToString() == "1")
                                    {

                                        string prefix = DateTime.Now.ToString("yyMMdd");
                                        long maPhieuDoi_check = long.Parse(prefix + "0001");

                                        maPhieuDoi = Bom_Change.Get_TA002(maPhieuDoi_check, erp, staging);
                                        Console.WriteLine("Mã phiếu mới: " + loaiPhieuDoi + "-" + maPhieuDoi);
                                        Console.WriteLine(ecn);
                                        string Document_Number = @"
                                        UPDATE ECN_Test
                                        SET 
                                           Document_Number = @Document_Number
                                        WHERE ECN = @ECN";

                                        using (var cmd = new SqlCommand(Document_Number, staging, tran))
                                        {
                                            cmd.Parameters.AddWithValue("@Document_Number", maPhieuDoi);
                                            cmd.Parameters.AddWithValue("@ECN", ecn["ECN"].ToString());

                                            int affected = cmd.ExecuteNonQuery();
                                        }

                                        Bom_Change.Insert_BOMTA_Staging_ERP(plm, staging, tran, ecn["ECN"].ToString(), ecn["CREATOR"].ToString(), company, loaiPhieuDoi, maPhieuDoi);
                                        Bom_Change.Insert_BOMTB_Staging_ERP_And_BOMTC_Staging_ERP(plm, erp, staging, tran, ecn["ECN"].ToString(), ecn["CREATOR"].ToString(), company, loaiPhieuDoi, maPhieuDoi);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //tran.Rollback();
                                    throw;
                                }
                                tran.Commit();

                            }


                            if (ecn["Inv_Change"].ToString() == "1")
                            {
                                Inv_Change.Inv_change(erp, plm, staging, ecn["ECN"].ToString(), ecn["CREATOR"].ToString(), company, ref success);
                            }

                            if (ecn["Bom_Change"].ToString() == "1")
                            {

                                //int loaiPhieuDoi = 410;

                                //// Tạo mã phiếu theo ngày hiện tại: YYMMDD0001
                                //string prefix = DateTime.Now.ToString("yyMMdd");
                                //long maPhieuDoi_check = long.Parse(prefix + "0001");

                                ////long maPhieuDoi = long.Parse("2511270001");
                                //// Lấy mã phiếu lớn nhất đang có trong DB
                                ////static void Bom_change(SqlConnection erp, SqlConnection plm, SqlConnection staging, string ecn, string creator, string company, int loaiPhieuDoi, long maPhieuDoi)


                                //long maPhieuDoi = Bom_Change.Get_TA002(maPhieuDoi_check, erp, staging);


                                //Console.WriteLine("Mã phiếu mới: " + loaiPhieuDoi + "-" + maPhieuDoi);
                                //Console.WriteLine(ecn);

                                //string Document_Number = @"
                                //        UPDATE ECN_Test
                                //        SET 
                                //           Document_Number = @Document_Number
                                //        WHERE ECN = @ECN";

                                //using (var cmd = new SqlCommand(Document_Number, staging))
                                //{
                                //    cmd.Parameters.AddWithValue("@Document_Number", maPhieuDoi);
                                //    cmd.Parameters.AddWithValue("@ECN", ecn["ECN"].ToString());

                                //    int affected = cmd.ExecuteNonQuery();
                                //}

                                Bom_Change.Bom_change(erp, plm, staging, ecn["ECN"].ToString(), ecn["CREATOR"].ToString(), company, loaiPhieuDoi, maPhieuDoi, ref success);
                                //Bom_Change.Bom_change(test_sai, plm, staging, ecn["ECN"].ToString(), ecn["CREATOR"].ToString(), company, loaiPhieuDoi, maPhieuDoi);

                            }

                            if (success) Helper.UpdateStagingSyncStatus(staging, "ECN_Test", new Dictionary<string, object> { { "ECN", ecn["ECN"].ToString() } });

                        }
                    }
                }
                catch (Exception ex)
                {
                Console.WriteLine("Lỗi tổng: " + ex.Message);
                }

            //Console.WriteLine("Nhấn Enter để thoát...");
            //Console.ReadLine();
            }
        }

    }
}

